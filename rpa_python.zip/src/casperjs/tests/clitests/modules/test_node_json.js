var casper = require('casper').create();
var json = require('json');
console.log(json.universe);
casper.exit();
