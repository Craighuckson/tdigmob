var casper = require('casper').create();
var foo = require('foo');
console.log(foo);
casper.exit();
